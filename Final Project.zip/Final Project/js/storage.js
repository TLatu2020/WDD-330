 function writeStorage(key, data) {
     window.localStorage.setItem(key, JSON.stringify(data));
 }

 function readStorage(key) {
     return JSON.parse(window.localStorage.getItem(key));
 }

 //  function renderCommentList(element, comments) {

 //      element.innerHTML = '';

 //      comments.forEach(el => {
 //          let item = document.createElement('li');

 //          item.innerHTML = `${el.name}: ${el.comment}`;

 //          element.appendChild(item);
 //      });
 //  }

 class Comments {
     constructor() {
         this.type = document.getElementById('location');

         //  const commentElementId = document.getElementById('comments');
         this.comments = readStorage(this.type.textContent) || [];

         console.log(this.comments);

     }

     getComments() {
         return this.comments;
     }


     addComment(content) {
         const newComment = {
             name: this.type.textContent,
             comment: content,
             date: new Date()
         };

         console.log(this.type);

         this.comments.push(newComment);
         writeStorage(this.type.textContent, this.comments);

         console.log(content)
     }

 }

 export default Comments;